# Superstore Sales Project: Build Instructions

Follow the parts in order. Every part uses the same cleaned file, so all your numbers will agree.

## 0. Setup (5 min)

1. Create a folder, e.g. `superstore_project/`, and put **all downloaded files in it**:

```
superstore_project/
  superstore_clean.csv            <- cleaned data (used by SQL, Python, Power BI)
  Superstore_Excel_Analysis.xlsx  <- Part 1
  superstore_postgres.sql         <- Part 2 (PostgreSQL)
  superstore_mysql.sql            <- Part 2 (MySQL)
  analysis.py                     <- Part 3
  PowerBI_Dashboard_Guide.md      <- Part 4 (build your own .pbix)
  Superstore_Dashboard.html       <- Part 4 (finished interactive dashboard)
  sales_trend.png                 <- Part 3 output
```

2. Install what you need (only the parts you plan to do):

| Part | Software |
|---|---|
| Excel | Microsoft Excel 2016+ |
| SQL | PostgreSQL 12+ **or** MySQL 8.0+ (MySQL 5.7 will not work: no window functions) |
| Python | Python 3.9+, then `pip install pandas matplotlib seaborn` |
| Power BI | Power BI Desktop (free, Windows only) |

**Expected figures to check against at every stage:** 9,799 line items | 4,922 orders | 793 customers | total sales $2,261,255.

---

## Part 1: Excel (clean + pivot)

**Option A (quick): open `Superstore_Excel_Analysis.xlsx`.** It already contains the cleaned data (`Clean_Data`), the Category × Region summary (`Pivot_Category_Region`) and a `Cleaning_Log`.

**Option B (do the cleaning yourself on the raw CSV, to show your work):**

1. Open `Superstore_Sales.csv` in Excel, then save as `.xlsx`.
2. **Remove duplicates:** select all data > **Data > Remove Duplicates** > untick **Row ID** (it is unique per row and would hide the duplicate) > OK. Excel reports 1 duplicate removed.
3. **Fix dates:** the dates are text in dd/mm/yyyy. Select the Order Date column > **Data > Text to Columns** > Next > Next > Column data format **Date: DMY** > Finish. Repeat for Ship Date. Then format both as `yyyy-mm-dd` (Ctrl+1 > Custom).
4. **Fix postal codes:** select the Postal Code column > Format Cells > **Text**, then retype/pad to 5 digits (or use `=TEXT(L2,"00000")` in a helper column and paste as values). Fill the 11 blank Burlington, VT codes with `05401`.
5. **Convert to a Table:** click in the data > **Ctrl+T**.

**Build the native PivotTable:**

1. Click any cell in the data > **Insert > PivotTable** > New Worksheet.
2. Drag **Category** to Rows, **Region** to Columns, **Sales** to Values (Sum of Sales).
3. Right-click a Sales value > Number Format > Currency, 0 decimals.
4. Optional: **PivotTable Analyze > PivotChart** (clustered column), and **Insert > Slicer** on Segment or Order Year.

**Check:** Grand Total = $2,261,255; Technology $827,456 / Furniture $728,377 / Office Supplies $705,422.

---

## Part 2: SQL

Run **either** PostgreSQL **or** MySQL (both scripts give identical results). Run the command from inside your project folder so the script can find `superstore_clean.csv`.

### PostgreSQL
```bash
cd superstore_project
createdb superstore
psql -d superstore -f superstore_postgres.sql
```
Windows: use the **SQL Shell (psql)** app, run `\c superstore` after creating the database, then `\cd 'C:/path/to/superstore_project'` and `\i superstore_postgres.sql`.

> pgAdmin's query tool does **not** understand `\copy`. If you use pgAdmin, run the `CREATE TABLE` part, then right-click the table > **Import/Export Data** > pick the CSV, tick Header, delimiter `,`. Then run the queries.

### MySQL
```sql
-- once, as an admin user:
SET GLOBAL local_infile = 1;
```
```bash
cd superstore_project
mysql --local-infile=1 --default-character-set=utf8mb4 -u root -p < superstore_mysql.sql
```
MySQL Workbench: run the `CREATE TABLE` part, then right-click the table > **Table Data Import Wizard** > choose the CSV.

### What the script does
1. Creates the `superstore` table. `postal_code` is `CHAR(5)` (text) so leading zeros survive.
2. Loads the CSV.
3. Prints a sanity check, then runs the four queries: **top 10 products**, **monthly sales** (with month-over-month % and running YTD), **sales by region**, **top customers by orders**.

**Check:** sanity query returns 9799 / 4922 / 793 / 2261255.41. #1 product = Canon imageCLASS 2200 Advanced Copier ($61,599.82). #1 customer = Emily Phan (17 orders).

> There is no profit column in this dataset, so query 3 reports sales by region. A ready-to-use profit version is commented out in the script.

---

## Part 3: Python

```bash
cd superstore_project
pip install pandas matplotlib seaborn
python analysis.py
```

Output: **`sales_trend.png`** (monthly trend + 3-month average, and a year-over-year seasonality chart), plus annual totals and growth printed to the console.

To use a different file or output folder: `python analysis.py path/to/file.csv output_folder`.

The **discount vs profit scatter** (`discount_vs_profit.png`) is created automatically if the input file has `discount` and `profit` columns. With this dataset it prints a "SKIPPED" message, which is expected.

Prefer Jupyter? Copy the sections of `analysis.py` (separated by the `# ----` comment lines) into notebook cells, and replace `matplotlib.use("Agg")` with `%matplotlib inline`.

**Check:** annual sales 2015 $479,575 | 2016 $459,436 | 2017 $600,193 | 2018 $722,052.

---

## Part 4: Dashboard

**Finished version:** open `Superstore_Dashboard.html` in any browser (no install, works offline except for the font). It has the four KPI cards, the monthly sales line chart, a tile-grid region map and a category slicer. Click a state or a region chip to filter everything. The Profit card is shown as "Not available" because the source file has no profit column.

**Power BI version:** a `.pbix` file cannot be generated outside Power BI Desktop, so build it yourself from the guide below (about 30-45 minutes).

Follow **`PowerBI_Dashboard_Guide.md`** (load > date table > measures > visuals). It has paste-ready DAX and a table of expected values.

Key points: set `postal_code` to **Text**, count orders with `DISTINCTCOUNT(order_id)`, and set the line chart axis to **Continuous**.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Excel shows `########` in date cells | Widen the column |
| Excel dates read as 2017-08-11 when they should be 08-Nov | The date was parsed as mm/dd. Redo Text to Columns with **DMY** |
| `\copy: No such file` (Postgres) | You are not in the folder containing the CSV |
| `The used command is not allowed` (MySQL) | `local_infile` is off: run `SET GLOBAL local_infile=1;` and connect with `--local-infile=1` |
| MySQL `syntax error near OVER` | MySQL older than 8.0: upgrade |
| Accented names garbled (e.g. Häberlin) | Add `--default-character-set=utf8mb4` |
| `ModuleNotFoundError` (Python) | `pip install pandas matplotlib seaborn` |
| Power BI map is blank | Enable File > Options > Security > Map and Filled map visuals; set `state` data category to State or Province |
| Order count in Power BI is 9,799 | You counted rows. Use `DISTINCTCOUNT(order_id)` to get 4,922 |

---

## Presenting it as a portfolio project

- Put the folder on GitHub; add `sales_trend.png` and a screenshot of your Power BI dashboard to the README.
- Mention the data-quality findings (duplicate, text dates, lost leading zeros, unreliable Product ID) as they show real cleaning judgement.
- Be upfront that this dataset has no profit/discount columns. If you can get the full Superstore file, re-run all four parts to add the profit analysis.

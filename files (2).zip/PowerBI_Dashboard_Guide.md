# Power BI Dashboard Guide: Superstore Sales

Build time: about 30-45 minutes. Source file: `superstore_clean.csv` (already cleaned).

> **Important: no Profit column.** The source file has only `sales`. The brief asks for a Profit KPI card, but profit cannot be calculated from this data. This guide uses **Sales, Orders, and Avg Order Value** as the three KPI cards, and includes the Profit measures (Section 3) ready to switch on if you obtain the full Superstore file.
>
> **Not tested in Power BI.** Power BI Desktop is Windows software and was not available where this guide was prepared. The DAX is standard and simple, and every number it should produce is listed in Section 7 (computed independently from the same data), so you can check your work.

---

## 1. Load the data

1. **Home > Get data > Text/CSV** > select `superstore_clean.csv` > **Transform Data**.
2. In Power Query, set these data types (right-click column header > Change Type):

| Column | Type | Why |
|---|---|---|
| `order_date`, `ship_date` | **Date** | Needed for time intelligence |
| `postal_code` | **Text** | Keeps leading zeros (e.g. `06040`). Power BI guesses "Whole number" and will strip them |
| `sales` | **Fixed decimal number** | Currency-safe |
| `row_id` | Whole number | |
| everything else | Text | |

3. Rename the query from `superstore_clean` to **`Superstore`** (right panel, Query Settings > Name).
4. **Close & Apply**.

## 2. Create a date table

**Modeling > New table**, paste:

```dax
Dim_Date =
ADDCOLUMNS (
    CALENDAR (
        DATE ( YEAR ( MIN ( Superstore[order_date] ) ), 1, 1 ),
        DATE ( YEAR ( MAX ( Superstore[order_date] ) ), 12, 31 )
    ),
    "Year", YEAR ( [Date] ),
    "Month Number", MONTH ( [Date] ),
    "Month", FORMAT ( [Date], "mmm" ),
    "Month Start", DATE ( YEAR ( [Date] ), MONTH ( [Date] ), 1 )
)
```

Then:
- Select `Dim_Date` > **Table tools > Mark as date table** > choose `Date`.
- Select the `Month` column > **Column tools > Sort by column** > `Month Number`.
- **Model view**: confirm a relationship `Dim_Date[Date]` (one) to `Superstore[order_date]` (many). If it was not created automatically, drag one onto the other.

## 3. Create measures

Right-click the `Superstore` table > **New measure**, once per measure:

```dax
Total Sales      = SUM ( Superstore[sales] )
Total Orders     = DISTINCTCOUNT ( Superstore[order_id] )
Total Customers  = DISTINCTCOUNT ( Superstore[customer_id] )
Avg Order Value  = DIVIDE ( [Total Sales], [Total Orders] )

Sales PY   = CALCULATE ( [Total Sales], SAMEPERIODLASTYEAR ( Dim_Date[Date] ) )
Sales YoY % = DIVIDE ( [Total Sales] - [Sales PY], [Sales PY] )
```

> **Orders, not rows.** The file has 9,799 line items but only 4,922 orders (one order has many products). Always count `DISTINCTCOUNT(order_id)`, never `COUNTROWS`.

**Profit measures (only if you load a file with a `profit` column):**

```dax
Total Profit    = SUM ( Superstore[profit] )
Profit Margin % = DIVIDE ( [Total Profit], [Total Sales] )
```

Format: `Total Sales`, `Avg Order Value` as Currency ($, 0 decimals); `Sales YoY %` and `Profit Margin %` as Percentage (1 decimal); `Total Orders` as Whole number with thousands separator. (Select the measure > Measure tools ribbon.)

## 4. Build the visuals

Use a 16:9 page (View > Page view > Fit to page). Suggested layout:

```
+----------------------------------------------------------------------+
|  Superstore Sales Dashboard                      [Year slicer]       |
+------------------+------------------+------------------+-------------+
|  TOTAL SALES     |  TOTAL ORDERS    |  AVG ORDER VALUE | [Category   |
|  $2.26M          |  4,922           |  $459            |  slicer]    |
|  (YoY %)         |                  |  (or Profit)     |             |
+------------------+------------------+------------------+             |
|  MONTHLY SALES (line chart)         |  SALES BY REGION  |             |
|                                     |  (filled map)     |             |
+-------------------------------------+-------------------+-------------+
```

**KPI cards (x3)**: Insert **Card** (or "Card (new)"). Fields: `Total Sales`; `Total Orders`; `Avg Order Value`. On the Total Sales card add `Sales YoY %` as a reference label (Card (new): drag into the "Reference labels" well). To use Profit instead, swap in `Total Profit`.

**Monthly line chart**: Insert **Line chart**. X-axis = `Dim_Date[Month Start]` (set the axis **Type = Continuous**, otherwise it shows a Year > Quarter > Month hierarchy). Y-axis = `Total Sales`. Optional: Analytics pane > **Trend line** or **Average line**.

**Region map**: Insert **Filled map**.
- Location = `Superstore[state]`. Select the `state` column > Column tools > **Data category = State or Province**.
- Legend = `Superstore[region]` (colours each state by its region: this is what makes it a *region* map).
- Tooltips = `Total Sales`, `Total Orders`.
- For correct geocoding, also set `country` > Data category = **Country/Region** and drag it above `state` in Location.
- If the map shows blank: File > Options > Security > enable **Map and Filled map visuals**. In the Power BI Service your admin must allow map visuals too. **Azure Map** is an alternative visual.

**Category slicer**: Insert **Slicer** > field `Superstore[category]` > Format > Slicer settings > Options > **Style: Tile** (buttons look best for 3 values). Add a second slicer on `Dim_Date[Year]` if you want year filtering.

Cross-filtering between all visuals is on by default, so clicking a category or a state filters everything else. Check with **Format > Edit interactions** if any visual does not respond.

## 5. Polish (optional)
- View > Themes > pick a palette; keep one accent colour for the line chart.
- Turn off visual titles you do not need; add a text box title "Superstore Sales Dashboard".
- Align with Format > Align; set equal card sizes.

## 6. Save and share
Save as `.pbix`. To share, **Publish** to the Power BI Service (requires a work/school account).

## 7. Verify your numbers (computed independently from the cleaned data)

| Check | Expected value |
|---|---|
| Total Sales | **$2,261,255** (2.26M) |
| Total Orders | **4,922** |
| Total Customers | **793** |
| Avg Order Value | **$459.42** |
| Sales by year | 2015: $479,575 / 2016: $459,436 / 2017: $600,193 / 2018: $722,052 |
| Sales YoY % for 2018 | **+20.3%** |
| Sales by region | West $710,220 / East $669,237 / Central $492,647 / South $389,151 |
| Sales by category | Technology $827,456 / Furniture $728,377 / Office Supplies $705,422 |
| States on the map | 49 (48 states + District of Columbia) |
| Peak month | Nov 2018, $117,938 |

If any value differs, the usual causes are: `postal_code`/dates typed wrongly in Power Query, the relationship to `Dim_Date` missing, or `COUNTROWS` used instead of `DISTINCTCOUNT`.

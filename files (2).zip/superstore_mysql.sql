-- =====================================================================
-- Superstore Sales  |  MySQL 8.0+  (window functions require 8.0)
-- Run from the folder containing superstore_clean.csv:
--     mysql --local-infile=1 --default-character-set=utf8mb4 -u root -p < superstore_mysql.sql
-- (LOAD DATA LOCAL needs local_infile enabled on the SERVER too:
--     SET GLOBAL local_infile = 1;   -- run once as an admin user)
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. SCHEMA
-- ---------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS superstore;
USE superstore;

DROP TABLE IF EXISTS superstore;

CREATE TABLE superstore (
    row_id        INTEGER       PRIMARY KEY,
    order_id      VARCHAR(20)   NOT NULL,
    order_date    DATE          NOT NULL,
    ship_date     DATE          NOT NULL,
    ship_mode     VARCHAR(20),
    customer_id   VARCHAR(10)   NOT NULL,
    customer_name VARCHAR(60),
    segment       VARCHAR(20),
    country       VARCHAR(40),
    city          VARCHAR(60),
    state         VARCHAR(40),
    postal_code   CHAR(5),               -- text, NOT numeric: keeps leading zeros (e.g. 06040)
    region        VARCHAR(10),
    product_id    VARCHAR(20),
    category      VARCHAR(30),
    sub_category  VARCHAR(30),
    product_name  VARCHAR(255),
    sales         DECIMAL(12,4) NOT NULL,
    CONSTRAINT chk_sales_nonneg CHECK (sales >= 0)
) DEFAULT CHARSET = utf8mb4;

-- ---------------------------------------------------------------------
-- 2. LOAD  (LOCAL = read the file from YOUR machine)
-- ---------------------------------------------------------------------
LOAD DATA LOCAL INFILE 'superstore_clean.csv'
INTO TABLE superstore
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'          -- use '\r\n' if the CSV was re-saved on Windows
IGNORE 1 LINES;

CREATE INDEX idx_ss_order_date ON superstore (order_date);
CREATE INDEX idx_ss_customer   ON superstore (customer_id);
CREATE INDEX idx_ss_region     ON superstore (region);
ANALYZE TABLE superstore;

-- ---------------------------------------------------------------------
-- 3. SANITY CHECK  (expect 9,799 rows | 4,922 orders | 2,261,255.41 sales)
-- ---------------------------------------------------------------------
SELECT COUNT(*)                     AS line_items,
       COUNT(DISTINCT order_id)     AS orders,
       COUNT(DISTINCT customer_id)  AS customers,
       ROUND(SUM(sales), 2)         AS total_sales,
       MIN(order_date)              AS first_order,
       MAX(order_date)              AS last_order
FROM superstore;

-- ---------------------------------------------------------------------
-- 4. QUERY 1: TOP 10 PRODUCTS BY SALES
--    Grouped by product_name, NOT product_id: in this dataset 32
--    product_ids map to more than one product_name, so id is not a safe key.
-- ---------------------------------------------------------------------
SELECT RANK() OVER (ORDER BY SUM(sales) DESC) AS sales_rank,
       product_name,
       category,
       sub_category,
       ROUND(SUM(sales), 2)                   AS total_sales,
       COUNT(DISTINCT order_id)               AS orders
FROM superstore
GROUP BY product_name, category, sub_category
ORDER BY total_sales DESC
LIMIT 10;

-- ---------------------------------------------------------------------
-- 5. QUERY 2: MONTHLY SALES  (with month-over-month % and running YTD)
-- ---------------------------------------------------------------------
WITH monthly AS (
    SELECT DATE_SUB(order_date, INTERVAL DAYOFMONTH(order_date) - 1 DAY) AS month,
           SUM(sales)                            AS sales,
           COUNT(DISTINCT order_id)              AS orders
    FROM superstore
    GROUP BY month
)
SELECT month,
       ROUND(sales, 2)  AS monthly_sales,
       orders,
       ROUND(100.0 * (sales - LAG(sales) OVER (ORDER BY month))
                   / NULLIF(LAG(sales) OVER (ORDER BY month), 0), 1) AS mom_change_pct,
       ROUND(SUM(sales) OVER (PARTITION BY YEAR(month)
                              ORDER BY month), 2)                    AS ytd_sales
FROM monthly
ORDER BY month;

-- ---------------------------------------------------------------------
-- 6. QUERY 3: PROFIT BY REGION
--    This CSV has NO profit column, so the query below reports SALES by
--    region (plus orders / customers / average order value).
-- ---------------------------------------------------------------------
SELECT region,
       ROUND(SUM(sales), 2)                                  AS total_sales,
       ROUND(100.0 * SUM(sales) / SUM(SUM(sales)) OVER (), 1) AS pct_of_total,
       COUNT(DISTINCT order_id)                              AS orders,
       COUNT(DISTINCT customer_id)                           AS customers,
       ROUND(SUM(sales) / COUNT(DISTINCT order_id), 2)       AS avg_order_value
FROM superstore
GROUP BY region
ORDER BY total_sales DESC;

-- >>> If you load the FULL Superstore file, add `profit DECIMAL(12,4)` (and
-- >>> discount, quantity) to the CREATE TABLE above, then use:
--
-- SELECT region,
--        ROUND(SUM(sales), 2)                          AS total_sales,
--        ROUND(SUM(profit), 2)                         AS total_profit,
--        ROUND(100.0 * SUM(profit) / NULLIF(SUM(sales), 0), 1) AS profit_margin_pct
-- FROM superstore
-- GROUP BY region
-- ORDER BY total_profit DESC;

-- ---------------------------------------------------------------------
-- 7. QUERY 4: CUSTOMERS WITH THE MOST ORDERS (top 10)
--    An "order" = distinct order_id (an order has many line items).
--    Ties on order count are broken by total sales; order_rank shows ties.
--    NOTE: ties are common here (18 customers have exactly 12 orders), so
--    LIMIT 10 shows only some of the customers tied at rank 6.
-- ---------------------------------------------------------------------
SELECT RANK() OVER (ORDER BY COUNT(DISTINCT order_id) DESC) AS order_rank,
       customer_id,
       customer_name,
       segment,
       COUNT(DISTINCT order_id)  AS orders,
       ROUND(SUM(sales), 2)      AS total_sales,
       MIN(order_date)           AS first_order,
       MAX(order_date)           AS last_order
FROM superstore
GROUP BY customer_id, customer_name, segment
ORDER BY orders DESC, total_sales DESC
LIMIT 10;

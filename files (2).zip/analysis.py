"""
Superstore Sales - Python analysis (pandas + matplotlib/seaborn)

Usage:
    python analysis.py                              # uses superstore_clean.csv next to this script
    python analysis.py path/to/file.csv out_folder

Outputs:
    sales_trend.png          monthly sales trend + year-over-year seasonality
    discount_vs_profit.png   ONLY if the input has 'discount' and 'profit' columns

Requires: pandas, matplotlib, seaborn
"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")                       # render to files; works without a display
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.ticker as mtick
import pandas as pd
import seaborn as sns

HERE = Path(__file__).resolve().parent
CSV = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "superstore_clean.csv"
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE
OUT.mkdir(parents=True, exist_ok=True)

sns.set_theme(style="whitegrid", font="DejaVu Sans")
NAVY, ORANGE = "#1F3864", "#E07B00"


# ----------------------------------------------------------------- load
def load(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    # accept either 'Order Date' (original headers) or 'order_date' (cleaned file)
    df.columns = df.columns.str.strip().str.lower().str.replace(r"[\s\-]+", "_", regex=True)
    # dates: cleaned file is ISO (yyyy-mm-dd); the raw Kaggle file is dd/mm/yyyy
    first = str(df["order_date"].iloc[0])
    fmt = "%Y-%m-%d" if first[:4].isdigit() else "%d/%m/%Y"
    df["order_date"] = pd.to_datetime(df["order_date"], format=fmt)
    # same cleaning rule as the Excel/SQL steps: ignore the surrogate row id when de-duplicating
    before = len(df)
    df = df.drop_duplicates(subset=[c for c in df.columns if c != "row_id"])
    if len(df) < before:
        print(f"Removed {before - len(df)} duplicate row(s)")
    return df


df = load(CSV)
print(f"Loaded {len(df):,} rows | {df['order_date'].min():%Y-%m-%d} to {df['order_date'].max():%Y-%m-%d}"
      f" | total sales ${df['sales'].sum():,.2f}")

# ----------------------------------------------------------------- 1. sales trend
monthly = (df.set_index("order_date")["sales"].resample("MS").sum().rename("sales").to_frame())
monthly["rolling_3m"] = monthly["sales"].rolling(3).mean()
yearly = monthly["sales"].groupby(monthly.index.year).sum()
yoy = yearly.pct_change() * 100
print("\nAnnual sales and YoY growth:")
print(pd.DataFrame({"sales": yearly.round(0), "yoy_%": yoy.round(1)}).to_string())

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 9.5), gridspec_kw={"height_ratios": [1.25, 1]})

ax1.plot(monthly.index, monthly["sales"], color=NAVY, lw=1.4, marker="o", ms=3.5, alpha=.85, label="Monthly sales")
ax1.plot(monthly.index, monthly["rolling_3m"], color=ORANGE, lw=2.6, label="3-month rolling average")
peak = monthly["sales"].idxmax()
ax1.annotate(f"Peak: {peak:%b %Y}\n${monthly['sales'].max():,.0f}",
             xy=(peak, monthly["sales"].max()), xytext=(-95, -8), textcoords="offset points",
             arrowprops=dict(arrowstyle="->", color="grey"), fontsize=9)
ax1.set_title("Monthly Sales, 2015-2018", loc="left", fontsize=14, fontweight="bold")
ax1.set_ylabel("Sales")
ax1.xaxis.set_major_locator(mdates.MonthLocator(bymonth=(1, 7)))
ax1.xaxis.set_major_formatter(mdates.DateFormatter("%b %Y"))
ax1.yaxis.set_major_formatter(mtick.FuncFormatter(lambda v, _: f"${v/1000:,.0f}K"))
ax1.legend(loc="upper left", frameon=True)

# seasonality: one line per year, Jan..Dec
pivot = monthly["sales"].groupby([monthly.index.year, monthly.index.month]).sum().unstack(0)
palette = sns.color_palette("Blues", n_colors=len(pivot.columns) + 2)[2:]
for color, year in zip(palette, pivot.columns):
    ax2.plot(pivot.index, pivot[year], marker="o", ms=4, lw=2, color=color, label=str(year))
ax2.set_xticks(range(1, 13))
ax2.set_xticklabels(["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"])
ax2.set_title("Seasonality: Monthly Sales, Year over Year", loc="left", fontsize=14, fontweight="bold")
ax2.set_ylabel("Sales")
ax2.yaxis.set_major_formatter(mtick.FuncFormatter(lambda v, _: f"${v/1000:,.0f}K"))
ax2.legend(title="Year", ncol=4, loc="upper left", frameon=True)

fig.tight_layout()
fig.savefig(OUT / "sales_trend.png", dpi=150)
plt.close(fig)
print(f"\nSaved {OUT / 'sales_trend.png'}")

# ----------------------------------------------------------------- 2. discount vs profit
if {"discount", "profit"}.issubset(df.columns):
    corr = df["discount"].corr(df["profit"])
    print(f"\nCorrelation (discount, profit): {corr:.3f}")
    bands = pd.cut(df["discount"], [-0.001, 0, 0.2, 0.4, 1.0], labels=["0%", "1-20%", "21-40%", ">40%"])
    print("Average profit per line item by discount band:")
    print(df.groupby(bands, observed=True)["profit"].agg(["mean", "count"]).round(2).to_string())

    fig, ax = plt.subplots(figsize=(10, 6.5))
    hue = "category" if "category" in df.columns else None
    sns.scatterplot(data=df, x="discount", y="profit", hue=hue, alpha=.45, s=26, edgecolor=None, ax=ax)
    sns.regplot(data=df, x="discount", y="profit", scatter=False, color="black",
                line_kws={"lw": 1.6, "ls": "--"}, ax=ax)
    ax.axhline(0, color="grey", lw=.9)
    ax.xaxis.set_major_formatter(mtick.PercentFormatter(1.0))
    ax.set_title(f"Discount vs Profit  (r = {corr:.2f})", loc="left", fontsize=14, fontweight="bold")
    ax.set_xlabel("Discount")
    ax.set_ylabel("Profit per line item ($)")
    fig.tight_layout()
    fig.savefig(OUT / "discount_vs_profit.png", dpi=150)
    plt.close(fig)
    print(f"Saved {OUT / 'discount_vs_profit.png'}")
else:
    missing = sorted({"discount", "profit"} - set(df.columns))
    print(f"\nSKIPPED discount-vs-profit scatter: column(s) {missing} not in {CSV.name}.\n"
          "Run this script on the full Superstore file (which has Discount and Profit) to generate it.")
